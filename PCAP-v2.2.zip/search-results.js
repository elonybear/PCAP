var active = 0;
var flip = [0, 0, 0, 0];

$(".filter").click(function(e){
	e.preventDefault();
	if(!$(this).hasClass("active")){
		//Inactive filter clicked
	
		//Removing active class from previously active filter
		var old_active = $("#filter-buttons").children().eq(active);
		old_active.switchClass("active", "inactive");
		old_active.find("img").addClass("inactive-triangle");				

		//Adding active class to clicked filter
		$(this).switchClass("inactive", "active");
		active = $(".filter").index(this);
		$(this).find("img").removeClass("inactive-triangle");
	}
	else{
		//Active filter clicked
		
		//Rotate triangle by 180 degrees	
		flip[active] += 180;
		$(this).find("img").css("transform",  "rotate(" + flip[active] + "deg)");
	}	
});

$(document).on("mouseover", ".result-button", function(){
	$(this).children().css({
		"color":"#00BFFF",
		"text-decoration":"underline"
	}); 
});

$(document).on("mouseout", ".result-button", function(){
	$(this).children().css({
		"color":"gray",
		"text-decoration":"none"
	});
})

$(document).on("mousedown", ".result-button", function(){
	$(this).children().css("color", "#0099CC");
});

$(document).on("mouseup", ".result-button", function(){
	$(this).children().css("color", "#00BFFF");	
});


var values = [];
var editing = -1;
var num_elements = 0;
$(document).on("click", ".result-button", function(e){ //Click on 'Edit', 'Remove', 'Save', or 'Cancel'
	e.preventDefault();
	//If the button clicked is not in the result currently being edited
	if(editing != -1){ 		
		$(this).parents("div").each(function(){
			if($(this).hasClass("search-result")){
				//Traverse to parent search-result 'div'
				if($(this).index() != editing){
					//Click the Cancel button in the search-result currently being edited
					$("#all-search-results-div").children().eq(editing).find(".result-buttons").children().eq(1).click();
				}
			}
		});
	}
	if($(this).children().html() == "Remove"){
		$(this).parents("div").each(function(){
			if($(this).hasClass("search-result")){
				$(this).remove();
				num_elements--;
				console.log(num_elements);
				return false;
			}
		});
	}
	else if($(this).children().html() == "Edit"){
		$(this).children().html("Save");
		$(this).parent().children().eq(1).children().html("Cancel");
		$(this).parents("div").each(function(){
			if($(this).hasClass("search-result")){
				editing = $(this).index();
				for(var data = 0; data < 3; data++){
					var text = $(this).children().eq(data).children().html();
					values.push(text);
					if(data == 0){
						$(this).children().eq(data).children().replaceWith("<input type ='text' class='data-input title-input' value='" + text + "'>");
					}
					if(data == 1){
						$(this).children().eq(data).css("padding", 0);
						$(this).children().eq(data).children().replaceWith("<input type ='text' class='data-input artist-input' value='" + text + "'>");
					}
					if(data == 2){
						$(this).children().eq(data).css("padding", 0);
						$(this).children().eq(data).children().replaceWith("<input type ='text' class='data-input institution-input' value='" + text + "'>");
					}
				}
				return false;
			}
		});
	}
	else if($(this).children().html() == "Save"){
		var index = 0;
		editing = -1;
		$(this).children().html("Edit");
		$(this).parent().children().eq(1).children().html("Remove");
		$(this).parents("div").each(function(){
			if($(this).hasClass("search-result")){
				for(var data = 0; data < 3; data++){
					if(data == 0){
						$(this).children().eq(data).children().replaceWith("<p class='search-result-data title-p'>" + $(this).children().eq(data).children().val() + "</p>");
					}
					if(data == 1){
						$(this).children().eq(data).children().replaceWith("<p class='search-result-data artist-p'>" + $(this).children().eq(data).children().val() + "</p>");
					}
					if(data == 2){
						$(this).children().eq(data).children().replaceWith("<p class='search-result-data institution-p'>" + $(this).children().eq(data).children().val() + "</p>");
					}
				}
				values = [];
				var max = 0;
				$(this).children(".data-wrapper").each(function(){
					if($(this).height() > max){
						max = $(this).height();
					}
				});

				$(this).children().each(function(){
					var difference = max - $(this).height();
					var padding = difference / 2;
					$(this).css("padding", padding + "px 0");
				});
				return false;
			}
		});
	}
	else{ //Click on 'Cancel'
		editing = -1;
		$(this).children().html("Remove");	
		$(this).parent().children().eq(0).children().html("Edit");
		$(this).parents("div").each(function(){
			if($(this).hasClass("search-result")){
				for(var data = 0; data < 3; data++){
					if(data == 0){
						$(this).children().eq(data).children().replaceWith("<p class='search-result-data title-p'>" + values[data] + "</p>");
					}
					if(data == 1){
						$(this).children().eq(data).css("padding", "9px 0");
						$(this).children().eq(data).children().replaceWith("<p class='search-result-data artist-p'>" + values[data] + "</p>");
					}
					if(data == 2){
						$(this).children().eq(data).css("padding", "9px 0");
						$(this).children().eq(data).children().replaceWith("<p class='search-result-data institution-p'>" + values[data] + "</p>");
					}
				}
				values = [];
				return false;
			}
		});
	}
});

$("#add-new-entry").click(function(e){			
	e.preventDefault();
	$("#wrapper").addClass("blur-filter");		
	$("#new-entry-overlay").fadeIn();
	$("#new-title-input").focus();	
});

$("#new-entry-x").click(function(e){
	e.preventDefault();
	$("#wrapper").removeClass("blur-filter");
	$("#new-entry-overlay").fadeOut();
	$(".login-input").val("");	
	$("#new-entry-form").children("p").each(function(){
		if($(this).css("display") == "block"){
			$(this).fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px");
		}
	});
});
var clicked = 0;
$("#submit-new-entry").click(function(e){
	e.preventDefault();
	if(!$("#new-title-input").val() && clicked){
		if($("#title-error").css("display") == "none"){
			$("#title-error").fadeIn();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() + 14 + "px");
		}
		else{
			$("#title-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#title-error").animate({
					"color":"#FA5858"
				});
			});
		}
	}	
	else{
		if($("#title-error").css("display") == "block"){
			$("#title-error").fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px"); 
		}
	}
	if(!$("#new-artist-input").val() && clicked){
		if($("#artist-error").css("display") == "none"){
			$("#artist-error").fadeIn();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() + 14 + "px");
		}
		else{
			$("#artist-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#artist-error").animate({
					"color":"#FA5858"
				});
			});
		}

	}	
	else{
		if($("#artist-error").css("display") == "block"){
			$("#artist-error").fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px"); 
		}
	}
	if(!$("#new-institution-input").val() && clicked){
		if($("#institution-error").css("display") == "none"){
			$("#institution-error").fadeIn();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() + 14 + "px");
		}
		else{
			$("#institution-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#institution-error").animate({
					"color":"#FA5858"
				});
			});
		}

	}	
	else{
		if($("#institution-error").css("display") == "block"){
			$("#institution-error").fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px"); 
		}
	}
	var num_filled = 0;
	$("#new-entry-form").children("input").each(function(){
		if($(this).val()){
			num_filled++;
		}	
	});
	if(num_filled == 3){
		var entry;
		entry = 
			"<div class='search-result'>" +
				"<div class='data-wrapper title-div'><p class='search-result-data title-p'>" + $("#new-title-input").val() + "</p></div>" +
				"<div class='data-wrapper artist-div'><p class='search-result-data artist-p'>" + $("#new-artist-input").val() + "</p></div>" +
				"<div class='data-wrapper institution-div'><p class='search-result-data institution-p'>" + $("#new-institution-input").val() + "</p></div>" +
				"<div class='result-buttons'>" +
					"<a href='' class='result-button edit-save'><p>Edit</p></a>" +
					"<a href='' class='result-button remove-cancel'><p>Remove</p></a>" +
				"</div>" +
			"</div>";
		$("#all-search-results-div").append(entry);
		num_elements++;
		console.log(num_elements);
		if($("#all-search-results-div").children().first().hasClass("search-result-gray") 
				|| num_elements == 1){
			console.log("First search result is gray or div is empty");
			if(num_elements % 2 || num_elements == 1){
				console.log("This element is the odd number element or div is empty");
				$(".search-result").last().addClass("search-result-gray");
			}
		}
		else{
			if(!(num_elements % 2)){
				$(".search-result").last().addClass("search-result-gray");
			}
		}
		var max = 0;
		$(".search-result").last().children(".data-wrapper").each(function(){
			if($(this).height() > max){
				max = $(this).height();
			}	
		});

		$(".search-result").last().children().each(function(){
			var difference = max - $(this).height();
			var padding = difference / 2;
			$(this).css("padding", padding + "px 0");
		});
		
		$("#new-entry-x").click();
	}
	clicked = 1;
});

$(document).keypress(function(e) {
	if($("#new-entry-wrapper").css("display") == "block"){
		if(e.which == 13){
			$("#submit-new-entry").click();
		}
	}
});
