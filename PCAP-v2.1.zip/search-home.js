$(document).ready(function(){
		$("#login-overlay").css("top", 0);
		$("#wrapper").addClass("blur-filter");		
		$("#username").focus();	
});

function hideLoginMenu(){	
	$("#login-overlay").css("top","-750px");
	$("#wrapper").removeClass("blur-filter");
	$("#username").css("box-shadow", "none");
	$("#password").css("box-shadow", "none");
	$("#username").val("");
	$("#password").val("");
	$("#login-error-message").css("display", "none");
}

$("#login-x").click(function(e){
	e.preventDefault();
	window.location = "search-results-user.html";
});

var count = 0;
$("#submit-login").click(function (e) {
	e.preventDefault();
	if($("#username").val() == "admin" && $("#password").val() == "hello"){	
		count = 0;
		hideLoginMenu();
	}
	else{
		count++;
		$("#password").val("");
		if($("#login-error").css("display") == "none"){
			$("#login-error").fadeIn();
			$("#login-wrapper").css("height", "250px");
		}
		else{
			$("#login-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#login-error").animate({
					"color":"#FA5858"
				});
			});
		}
	}
	if(count == 3){
		window.location = "search-results-user.html";	
	}
});

$(document).keypress(function(e) {
	if($("#login-wrapper").css("opacity") == .9){
		if(e.which == 13){
			$("#submit-login").click();
		}
	}
});

$("#add-new-entry").click(function(e){			
	e.preventDefault();
	console.log("New Entry Clicked");
	$("#wrapper").addClass("blur-filter");		
	$("#new-entry-overlay").fadeIn();
	$("#new-title-input").focus();	
});

$("#new-entry-x").click(function(e){
	e.preventDefault();
	$("#wrapper").removeClass("blur-filter");
	$("#new-entry-overlay").fadeOut();
	$(".login-input").val("");	
	$("#new-entry-form").children("p").each(function(){
		if($(this).css("display") == "block"){
			$(this).fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px");
		}
	});
});
var num_elements = 0;
var clicked = 0;
$("#submit-new-entry").click(function(e){
	e.preventDefault();
	if(!$("#new-title-input").val() && clicked){
		if($("#title-error").css("display") == "none"){
			$("#title-error").fadeIn();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() + 14 + "px");
		}
		else{
			$("#title-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#title-error").animate({
					"color":"#FA5858"
				});
			});
		}
	}	
	else{
		if($("#title-error").css("display") == "block"){
			$("#title-error").fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px"); 
		}
	}
	if(!$("#new-artist-input").val() && clicked){
		if($("#artist-error").css("display") == "none"){
			$("#artist-error").fadeIn();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() + 14 + "px");
		}
		else{
			$("#artist-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#artist-error").animate({
					"color":"#FA5858"
				});
			});
		}

	}	
	else{
		if($("#artist-error").css("display") == "block"){
			$("#artist-error").fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px"); 
		}
	}
	if(!$("#new-institution-input").val() && clicked){
		if($("#institution-error").css("display") == "none"){
			$("#institution-error").fadeIn();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() + 14 + "px");
		}
		else{
			$("#institution-error").animate({
				"color":"#FAAC58"	
			}, 200, function(){
				$("#institution-error").animate({
					"color":"#FA5858"
				});
			});
		}

	}	
	else{
		if($("#institution-error").css("display") == "block"){
			$("#institution-error").fadeOut();
			$("#new-entry-wrapper").css("height", $("#new-entry-wrapper").height() - 14 + "px"); 
		}
	}
	var count = 0;
	$("#new-entry-form").children("input").each(function(){
		if($(this).val()){
			count++;
		}	
	});
	if(count == 3){
		console.log("All inputs filled");
		var entry;
		entry = 
			"<div class='search-result'>" +
				"<div class='data-wrapper title-div'><p class='search-result-data title-p'>" + $("#new-title-input").val() + "</p></div>" +
				"<div class='data-wrapper artist-div'><p class='search-result-data artist-p'>" + $("#new-artist-input").val() + "</p></div>" +
				"<div class='data-wrapper institution-div'><p class='search-result-data institution-p'>" + $("#new-institution-input").val() + "</p></div>" +
				"<div class='result-buttons'>" +
					"<a href='' class='result-button edit-save'><p>Edit</p></a>" +
					"<a href='' class='result-button remove-cancel'><p>Remove</p></a>" +
				"</div>" +
			"</div>";
		$("#all-search-results-div").append(entry);
		num_elements++;
		if(num_elements % 2){
			$(".search-result").last().addClass("search-result-gray");
		}
		var max = 0;
		$(".search-result").last().children(".data-wrapper").each(function(){
			if($(this).height() > max){
				max = $(this).height();
			}	
		});

		$(".search-result").last().children().each(function(){
			var difference = max - $(this).height();
			var padding = difference / 2;
			$(this).css("padding", padding + "px 0");
		});
		
		$("#new-entry-x").click();
	}
	clicked = 1;
});

$(document).keypress(function(e) {
	if($("#new-entry-wrapper").css("display") == "block"){
		if(e.which == 13){
			$("#submit-new-entry").click();
		}
	}
});
